
package projectoop;

public class ProjectOOP {

    /* Student -> String s_level, String department, double gpa, String name, String address, String email,
  String password, int age, int id, int birth_date */
  /*Adminstrator->(String department, String job, String rank, double salary, double bonus,
          double deduction, String name, String address, String email,String password, int age, int id, int birth_date)*/
  //Department->(String dname)
  //Employee ->(String job, String rank, double salary, double bonus, double deduction)
  /*Instructor -> (String department, int num_materials, String job, String rank, double salary, double bonus, double deduction, String name,
  String address, String email, String password, int age, int id, int birth_date)*/
  //Person->(String name, String address, String email, String password, int age, int id, int birth_date) 
  /*Technicals(String placework_resp, String resp_id, int resp_level, String job, String rank, double salary, double bonus, double deduction, 
  String name, String address, String email,String password, int age, int id, int birth_date)*/
  /*Worker(String specilize, boolean PC_skills, String job, String rank, double salary, double bonus, double deduction, String name, 
  String address, String email, String password, int age, int id, int birth_date)*/
  /*graduated_student(int g_year, String s_level, String department, double gpa, String name, 
  String address, String email, String password, int age, int id, int birth_date)*/
  /*labs(String lab_Id, int lab_level, int number_devise, boolean projector)*/
    public static void main(String[] args) {
        System.out.println("welcome in faculty management system \n\n");
  try{
      Department d1 = new Department("it");
      Worker w1 = new Worker("social",true,"worker","middle",3300,150,50,"moahmed","assuit","addd@gmali","19292sss",30,162020,1991);  
          d1.add_employee(w1);
      Adminstrator a1 = new Adminstrator("CS","Owner","High",10000,500,100,"Dr.Nehad","Assiut","nehad@gmail.com","123456",24,5455,1997);
          d1.add_employee(a1);        

      Technicals t1 = new Technicals("Lap","1",2,"Technic","middle",4000,100,100,"Adel","Assiut","adel@gmail.com","8454454",29,9874,1992);
              d1.add_employee(t1);
          

      Technicals t2 = new Technicals("Lap","1",2,"Technic","lower",4000,100,100,"medhat","Assiut","adel@gmail.com","454454",29,974,1992);

        d1.add_employee(t1);

      Student s1= new Student("1","it",3.3,"mohamed","Assiut","mo@gmail.com","12345678",19,12345,2002);
        d1.add_student(s1);

      
         Student s2= new Student("2","iS",3.4,"ALI","Assiut","AL@gmail.com","1245678",19,12234443,2002);
         d1.add_student(s2);
                   

          Student s3= new Student("3","CS",3.0,"nada","giza","nana@gmail.com","123212378",18,122545,2003);
                   d1.add_student(s3);

            Student s4= new Student("3","CS",3.0,"nada","giza","nana@gmail.com","123212378",18,122545,2003);
          d1.add_student(s4);
        d1.print_details();
        d1.remove_student(s2);
        d1.remove_employee(t2);
        
        System.out.println();
        System.out.println();
        d1.print_details();
        System.out.println();
              if(s4.equals(s3))
                  System.out.println("Both s4 and s3 are equal");
              else 
                  System.out.println("Both s4 and s3 are not equal");
                      
        System.out.println("the number of the students is : "+ d1.get_stlist());  
        System.out.println("the number of the employee is : "+ d1.get_emplist()); 
        System.out.println();
        labs l1 =new labs("m2d",2,22,true);
        Faculty_stands fs = new Faculty_stands("m3",3,false);
        System.out.println(fs.toString());
        
        System.out.println(l1.toString());
        
  }
  catch(Exception e){
      System.out.println("Error");
  }
     
       

          }
}
