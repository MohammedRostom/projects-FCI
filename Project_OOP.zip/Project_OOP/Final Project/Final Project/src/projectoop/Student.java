/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectoop;

import java.util.Objects;

/**
 *
 * @author ALL IN ONE
 */
public class Student extends Person {
    String s_level,department;
    double gpa;

    public Student() {
    }

    public Student(String s_level, String department, double gpa) {
        this.s_level = s_level;
        this.department = department;
        this.gpa = gpa;
    }

    public Student(String s_level, String department, double gpa, String name, String address, String email, String password, int age, int id, int birth_date) {
        super(name, address, email, password, age, id, birth_date);
        this.s_level = s_level;
        this.department = department;
        this.gpa = gpa;
    }
    

    public String getS_level() {
        return s_level;
    }

    public void setS_level(String s_level) {
        this.s_level = s_level;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public double getGpa() {
        return gpa;
    }

    public void setGpa(double gpa) {
        this.gpa = gpa;
    }

    @Override
    public String toString() {
        return "Student{" + "s_level=" + s_level + ", department=" + department + ", gpa=" + gpa + '}';
    }

    public void Displayalldetails()
      {
          System.out.println(super.toString());
          System.out.println(toString());
      }

    

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Student other = (Student) obj;
        
        if (!Objects.equals(this.id, other.id)) {
            return false;
        }
           return true;
    }

    
   
    
}
