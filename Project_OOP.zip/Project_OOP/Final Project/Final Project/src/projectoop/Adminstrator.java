
package projectoop;


public class Adminstrator extends Employee implements Displayable {
    String department;

    public Adminstrator() {
    }

    public Adminstrator(String department) {
        this.department = department;
    }

    public Adminstrator(String department, String job, String rank, double salary, double bonus, double deduction, String name, String address, String email, String password, int age, int id, int birth_date) {
        super(job, rank, salary, bonus, deduction, name, address, email, password, age, id, birth_date);
        this.department = department;
    }
     
    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }
    @Override
    public double earning()
    {
       return (salary+bonus)-deduction;   
    }
    @Override
      public void Displayalldetails()
      {
          System.out.println(super.toString());
          System.out.println(toString());
      }
      
    @Override
       public void Displayearnings(){
           
           System.out.println("the total salary is "+earning());
           
       }
    @Override
    public String toString() {
        return "Adminstrator{" + "department=" + department + '}';
    }

   
   
       
}
