/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectoop;

import java.util.ArrayList;

/**
 *
 * @author LAPTOP
 */
public class Department {
    String dname;
    ArrayList <Employee> emplist;
    ArrayList <Student> stlist;

    public Department() {
    }

    public Department(String dname) {
        this.dname = dname;
     emplist =new  ArrayList <Employee>();
     stlist = new  ArrayList <Student>();
     
    }

    public String getDname() {
        return dname;
    }

    public void setDname(String dname) {
        this.dname = dname;
    }
    public void add_employee (Employee e)
    {
      emplist.add(e);
    }
      public void add_student (Student e)
    {
      stlist.add(e);
    }
   
    public void remove_employee (Employee e)
    {
        emplist.remove(e);
    }
    
     public void remove_student (Student s)
    {
        stlist.remove(s);
    }
     public int get_emplist()
     {
         return emplist.size();
     }
     public int get_stlist()
     {
         return stlist.size();
     }
     public void print_details ()
     {
         for (int i=0; i<emplist.size();i++){
             if (emplist.get(i) instanceof Adminstrator ){
                 ((Adminstrator) emplist.get(i)).Displayalldetails();
                 System.out.println("");
             }
             if (emplist.get(i) instanceof Technicals ){
                 ((Technicals) emplist.get(i)).Displayalldetails();
                 System.out.println("");
             }
             if (emplist.get(i) instanceof Instructor ){
                 ((Instructor) emplist.get(i)).Displayalldetails();
                 System.out.println("");
             }
             if (emplist.get(i) instanceof Worker ){
                 ((Worker) emplist.get(i)).Displayalldetails();
                 System.out.println("");
             }
              }
         for (int i=0; i<stlist.size();i++){
             if (stlist.get(i) instanceof Student ){
                 ((Student) stlist.get(i)).Displayalldetails();
                 System.out.println("");
             }
             if (stlist.get(i) instanceof graduated_student ){
                 ((graduated_student) stlist.get(i)).Displayalldetails();
                 System.out.println("");
             }                    
              }
         
     }
}
