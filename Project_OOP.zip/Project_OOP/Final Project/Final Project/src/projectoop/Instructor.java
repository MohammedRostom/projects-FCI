/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectoop;

/**
 *
 * @author ALL IN ONE
 */
public class Instructor extends Employee implements Displayable {
    String department;
    int num_materials;

    public Instructor() {
    }

    public Instructor(String department, int num_materials) {
        this.department = department;
        this.num_materials = num_materials;
    }

    public Instructor(String department, int num_materials, String job, String rank, double salary, double bonus, double deduction, String name, String address, String email, String password, int age, int id, int birth_date) {
        super(job, rank, salary, bonus, deduction, name, address, email, password, age, id, birth_date);
        this.department = department;
        this.num_materials = num_materials;
    }
     
    
    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public int getNum_materials() {
        return num_materials;
    }

    public void setNum_materials(int num_materials) {
        this.num_materials = num_materials;
    }
    @Override
    public double earning()
    {
        return (salary+bonus)-deduction;  
    }
    @Override
      public void Displayalldetails()
      {
          System.out.println(super.toString());
          System.out.println(toString());
      }
      
    @Override
       public void Displayearnings(){
           
           System.out.println("the total salary is "+earning());
           
       }

    @Override
    public String toString() {
        return "Instructor{" + "department=" + department + ", num_materials=" + num_materials + '}';
    }
       
}
