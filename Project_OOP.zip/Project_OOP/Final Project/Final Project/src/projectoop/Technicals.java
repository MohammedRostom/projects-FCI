/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectoop;

/**
 *
 * @author ALL IN ONE
 */
public class Technicals extends Employee implements Displayable {
    String placework_resp,resp_id;
    int resp_level;

    public Technicals() {
    }

    public Technicals(String placework_resp, String resp_id, int resp_level) {
        this.placework_resp = placework_resp;
        this.resp_id = resp_id;
        this.resp_level = resp_level;
    }

    public Technicals(String placework_resp, String resp_id, int resp_level, String job, String rank, double salary, double bonus, double deduction, String name, String address, String email, String password, int age, int id, int birth_date) {
        super(job, rank, salary, bonus, deduction, name, address, email, password, age, id, birth_date);
        this.placework_resp = placework_resp;
        this.resp_id = resp_id;
        this.resp_level = resp_level;
    }

      
    public String getPlacework_resp() {
        return placework_resp;
    }

    public void setPlacework_resp(String placework_resp) {
        this.placework_resp = placework_resp;
    }

    public String getResp_id() {
        return resp_id;
    }

    public void setResp_id(String resp_id) {
        this.resp_id = resp_id;
    }

    public int getResp_level() {
        return resp_level;
    }

    public void setResp_level(int resp_level) {
        this.resp_level = resp_level;
    }
    @Override
      public double earning()
    {
      return (salary+bonus)-deduction; 
        
    }
    @Override
       public void Displayalldetails()
      {
          System.out.println(super.toString());
          System.out.println(toString());
      }
      
    @Override
       public void Displayearnings(){
           
           System.out.println("the total salary is "+earning());
           
       }

    @Override
    public String toString() {
        return "Technicals{" + "placework_resp=" + placework_resp + ", resp_id=" + resp_id + ", resp_level=" + resp_level + '}';
    }
       
}
