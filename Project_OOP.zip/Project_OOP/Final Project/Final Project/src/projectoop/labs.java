/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectoop;

/**
 *
 * @author ALL IN ONE
 */
public class labs {
   String lab_Id;
  int lab_level,number_devise;
  boolean projector;

    public labs() {
    }

    public labs(String lab_Id, int lab_level, int number_devise, boolean projector) {
        this.lab_Id = lab_Id;
        this.lab_level = lab_level;
        this.number_devise = number_devise;
        this.projector = projector;
    }

    public String getLab_Id() {
        return lab_Id;
    }

    public void setLab_Id(String lab_Id) {
        this.lab_Id = lab_Id;
    }

    public int getLab_level() {
        return lab_level;
    }

    public void setLab_level(int lab_level) {
        this.lab_level = lab_level;
    }

    public int getNumber_devise() {
        return number_devise;
    }

    public void setNumber_devise(int number_devise) {
        this.number_devise = number_devise;
    }

    public boolean isProjector() {
        return projector;
    }

    public void setProjector(boolean projector) {
        this.projector = projector;
    }

    @Override
    public String toString() {
        return "labs{" + "lab_Id=" + lab_Id + ", lab_level=" + lab_level + ", number_devise=" + number_devise + ", projector=" + projector + '}';
    }
  
}
