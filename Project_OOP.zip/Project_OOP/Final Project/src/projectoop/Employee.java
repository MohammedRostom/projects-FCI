/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectoop;



public abstract class Employee extends Person {
    String job,rank;
    double salary,bonus,deduction;

    public Employee() {
    }

    public Employee(String job, String rank, double salary, double bonus, double deduction) {
        this.job = job;
        this.rank = rank;
        this.salary = salary;
        this.bonus = bonus;
        this.deduction = deduction;
    }

    public Employee(String job, String rank, double salary, double bonus, double deduction, String name, String address, String email, String password, int age, int id, int birth_date) {
        super(name, address, email, password, age, id, birth_date);
        this.job = job;
        this.rank = rank;
        this.salary = salary;
        this.bonus = bonus;
        this.deduction = deduction;
    }
    

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }

    public double getDeduction() {
        return deduction;
    }

    public void setDeduction(double deduction) {
        this.deduction = deduction;
    }
    public abstract double earning();

    @Override
    public String toString() {
        return super.toString() + "\nEmployee{" + "job=" + job + ", rank=" + rank + ", salary=" + salary + ", bonus=" + bonus + ", deduction=" + deduction + '}';
    }
    
    
}
