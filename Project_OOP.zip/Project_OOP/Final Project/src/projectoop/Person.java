/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectoop;

// this is the base class.

public class Person {
    String name,address,email,password;
    int age,id,birth_date;

    public Person() {
    }

    public Person(String name, String address, String email, String password, int age, int id, int birth_date) {
        this.name = name;
        this.address = address;
        this.email = email;
        this.password = password;
        this.age = age;
        this.id = id;
        this.birth_date = birth_date;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getBirth_date() {
        return birth_date;
    }

    public void setBirth_date(int birth_date) {
        this.birth_date = birth_date;
    }

    @Override
    public String toString() {
        return "Person{" + "name=" + name + ", address=" + address + ", email=" + email + ", password=" + password + ", age=" + age + ", id=" + id + ", birth_date=" + birth_date + '}';
    }

    

   
            
    
}
