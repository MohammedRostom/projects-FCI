
package projectoop;





public class graduated_student extends Student {
   int g_year;

    public graduated_student() {
    }

    public graduated_student(int g_year) {
        this.g_year = g_year;
    }

    public graduated_student(int g_year, String s_level, String department, double gpa, String name, String address, String email, String password, int age, int id, int birth_date) {
        super(s_level, department, gpa, name, address, email, password, age, id, birth_date);
        this.g_year = g_year;
    }

    public int getG_year() {
        return g_year;
    }

    public void setG_year(int g_year) {
        this.g_year = g_year;
    }

    @Override
    public String toString() {
        return super.toString()+" graduated_student{" + "g_year=" + g_year + '}';
    }
   
    
    
}
