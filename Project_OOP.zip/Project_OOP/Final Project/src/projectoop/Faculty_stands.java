/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectoop;

// this is class without inheritance.

public class Faculty_stands {
    String stand_id;
     int   stand_level;
    boolean projector;

    public Faculty_stands(String stand_id, int stand_level, boolean projector) {
        this.stand_id = stand_id;
        this.stand_level = stand_level;
        this.projector = projector;
    }

    public String getStand_id() {
        return stand_id;
    }

    public void setStand_id(String stand_id) {
        this.stand_id = stand_id;
    }

    public int getStand_level() {
        return stand_level;
    }

    public void setStand_level(int stand_level) {
        this.stand_level = stand_level;
    }

    public boolean isProjector() {
        return projector;
    }

    public void setProjector(boolean projector) {
        this.projector = projector;
    }

    @Override
    public String toString() {
        return "Faculty_stands{" + "stand_id=" + stand_id + ", stand_level=" + stand_level + ", projector=" + projector + '}';
    }
    
    
}
