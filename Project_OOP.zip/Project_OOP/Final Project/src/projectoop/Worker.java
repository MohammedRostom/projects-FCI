/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectoop;



public class Worker extends Employee implements Displayable {
    String specilize;
    boolean PC_skills;

    public Worker() {
    }
      
    public Worker(String specilize, boolean PC_skills) {
        this.specilize = specilize;
        this.PC_skills = PC_skills;
    }

    public Worker(String specilize, boolean PC_skills, String job, String rank, double salary, double bonus, double deduction, String name, String address, String email, String password, int age, int id, int birth_date) {
        super(job, rank, salary, bonus, deduction, name, address, email, password, age, id, birth_date);
        this.specilize = specilize;
        this.PC_skills = PC_skills;
    }

    public String getSpecilize() {
        return specilize;
    }

    public void setSpecilize(String specilize) {
        this.specilize = specilize;
    }

    public boolean isPC_skills() {
        return PC_skills;
    }

    public void setPC_skills(boolean PC_skills) {
        this.PC_skills = PC_skills;
    }
    @Override
      public double earning()
    {
       return (salary+bonus)-deduction;  
        
    }
    @Override
       public void Displayalldetails()
      {
          System.out.println(super.toString());
          System.out.println(toString());
      }
      
    @Override
       public void Displayearnings(){
           
           System.out.println("the total salary is "+earning());
           
       }

    @Override
    public String toString() {
        return "Worker{" + "specilize=" + specilize + ", PC_skills=" + PC_skills + '}';
    }
       
    
}
